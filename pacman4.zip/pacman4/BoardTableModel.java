import javax.swing.table.AbstractTableModel;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;
import javax.swing.ImageIcon;
import java.awt.Image;

public class BoardTableModel extends AbstractTableModel implements Serializable {
    public enum CellType {
        EMPTY, WALL, DOT, PLAYER, ENEMY, UPGRADE
    }

    public static final int UPGRADE_LIFE = 0;
    public static final int UPGRADE_SCORE = 1;
    public static final int UPGRADE_INVINCIBILITY = 2;
    public static final int UPGRADE_FREEZE = 3;
    public static final int UPGRADE_TELEPORT = 4;

    private static final Map<Integer, Image> upgradeIcons = new HashMap<>();
    private static boolean upgradeIconsLoaded = false;
    private static final Set<Integer> validUpgradeTypes = new HashSet<>();

    static {
        try {

            upgradeIcons.put(UPGRADE_LIFE, loadIcon("resources/life.png"));
            upgradeIcons.put(UPGRADE_SCORE, loadIcon("resources/score.png"));
            upgradeIcons.put(UPGRADE_INVINCIBILITY, loadIcon("resources/invincibility.png"));
            upgradeIcons.put(UPGRADE_FREEZE, loadIcon("resources/freeze.png"));
            upgradeIcons.put(UPGRADE_TELEPORT, loadIcon("resources/teleport.png"));


            for (Map.Entry<Integer, Image> entry : upgradeIcons.entrySet()) {
                if (entry.getValue() != null) {
                    validUpgradeTypes.add(entry.getKey());
                }
            }

            upgradeIconsLoaded = !validUpgradeTypes.isEmpty();
            if (!upgradeIconsLoaded) {
                System.err.println("Warning: No upgrade icons were loaded successfully!");
            } else {
                System.out.println("Successfully loaded " + validUpgradeTypes.size() + " upgrade icons");
            }
        } catch (Exception e) {
            System.err.println("Error loading upgrade icons in BoardTableModel: " + e.getMessage());
            upgradeIconsLoaded = false;
        }
    }

    private static Image loadIcon(String path) {
        try {
            java.net.URL imgURL = BoardTableModel.class.getClassLoader().getResource(path);
            System.out.println("Loading in BoardTableModel: " + path + " -> " + (imgURL != null ? "FOUND" : "NOT FOUND"));
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                return icon.getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH);
            }
        } catch (Exception e) {
            System.err.println("Error loading icon in BoardTableModel " + path + ": " + e.getMessage());
        }
        return null;
    }

    public boolean isWalkable(int newRow, int newCol) {
        return true;
    }

    private final int rows;
    private final int cols;
    private CellType[][] board;
    private boolean[][] frozenGhosts;
    private int[][] upgradeTypes;

    public BoardTableModel(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        board = new CellType[rows][cols];
        this.frozenGhosts = new boolean[rows][cols];
        this.upgradeTypes = new int[rows][cols];
        generateMazePrim();
    }

    private void generateBoard() {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (r == 0 || c == 0 || r == rows - 1 || c == cols - 1) {
                    board[r][c] = CellType.WALL;
                } else {
                    board[r][c] = CellType.DOT;
                }
            }
        }

        int playerStartRow = rows / 2;
        int playerStartCol = cols / 2;
        if (board[playerStartRow][playerStartCol] == CellType.WALL) {
            board[playerStartRow][playerStartCol] = CellType.DOT;
        }
        board[playerStartRow][playerStartCol] = CellType.PLAYER;

        board[rows / 2][cols / 2 - 1] = CellType.ENEMY;
        board[rows / 2][cols / 2 + 1] = CellType.ENEMY;
    }

    private void generateMazeDFS() {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                board[r][c] = CellType.WALL;
            }
        }

        boolean[][] visited = new boolean[rows][cols];
        java.util.Random rand = new java.util.Random();

        int startRow = 1 + rand.nextInt((rows - 2) / 2) * 2;
        int startCol = 1 + rand.nextInt((cols - 2) / 2) * 2;

        dfs(startRow, startCol, visited, rand);

        System.out.println("--- After DFS Carving ---");
        printSampleCellTypes();

        for (int r = 0; r < rows; r++) {
            board[r][0] = CellType.WALL;
            board[r][cols - 1] = CellType.WALL;
        }
        for (int c = 0; c < cols; c++) {
            board[0][c] = CellType.WALL;
            board[rows - 1][c] = CellType.WALL;
        }

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (board[r][c] != CellType.WALL) {
                    board[r][c] = CellType.DOT;
                }
            }
        }

        System.out.println("--- After Filling Non-Walls with Dots ---");
        printSampleCellTypes();

        List<int[]> possiblePositions = new ArrayList<>();
        for (int r = 1; r < rows - 1; r++) {
            for (int c = 1; c < cols - 1; c++) {
                if (board[r][c] == CellType.DOT) {
                    possiblePositions.add(new int[]{r, c});
                }
            }
        }

        Collections.shuffle(possiblePositions, rand);

        if (!possiblePositions.isEmpty()) {
            int[] playerPos = possiblePositions.remove(0);
            board[playerPos[0]][playerPos[1]] = CellType.PLAYER;
        }

        int numEnemies = 3;
        for (int i = 0; i < numEnemies && !possiblePositions.isEmpty(); i++) {
            int[] enemyPos = possiblePositions.remove(0);
            board[enemyPos[0]][enemyPos[1]] = CellType.ENEMY;
        }
    }

    private void printSampleCellTypes() {
        int[][] sampleCoords = {{1, 1}, {1, cols - 2}, {rows - 2, 1}, {rows - 2, cols - 2}, {rows / 2, cols / 2}};
        for (int[] coord : sampleCoords) {
            int r = coord[0];
            int c = coord[1];
            if (r >= 0 && r < rows && c >= 0 && c < cols) {
                System.out.println("Cell (" + r + ", " + c + "): " + board[r][c]);
            } else {
                System.out.println("Sample coordinate out of bounds: (" + r + ", " + c + ")");
            }
        }
    }

    private void dfs(int r, int c, boolean[][] visited, java.util.Random rand) {
        visited[r][c] = true;
        board[r][c] = CellType.DOT;

        int[][] dirs = {{0, -2}, {0, 2}, {-2, 0}, {2, 0}};
        
        shuffleArray(dirs, rand);

        for (int[] dir : dirs) {
            int nr = r + dir[0];
            int nc = c + dir[1];

            if (nr > 0 && nc > 0 && nr < rows - 1 && nc < cols - 1 && !visited[nr][nc]) {
                board[r + dir[0] / 2][c + dir[1] / 2] = CellType.DOT;
                dfs(nr, nc, visited, rand);
            }
        }
    }

    private void shuffleArray(int[][] array, java.util.Random rand) {
        for (int i = array.length - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            int[] temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }

    private void generateBlockMaze() {

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                board[r][c] = CellType.WALL;
            }
        }

        Random rand = new Random();
        

        for (int r = 1; r < rows - 1; r++) {
            for (int c = 1; c < cols - 1; c++) {

                if (rand.nextDouble() < 0.6) {
                    board[r][c] = CellType.DOT;
                    

                    if (rand.nextDouble() < 0.3 && c + 1 < cols - 1) {
                        board[r][c + 1] = CellType.DOT;
                    }
                    if (rand.nextDouble() < 0.3 && r + 1 < rows - 1) {
                        board[r + 1][c] = CellType.DOT;
                    }
                }
            }
        }

        for (int r = 0; r < rows; r++) {
            board[r][0] = CellType.WALL;
            board[r][cols - 1] = CellType.WALL;
        }
        for (int c = 0; c < cols; c++) {
            board[0][c] = CellType.WALL;
            board[rows - 1][c] = CellType.WALL;
        }


        for (int i = 0; i < (rows * cols) / 10; i++) {
            int r = 1 + rand.nextInt(rows - 2);
            int c = 1 + rand.nextInt(cols - 2);

            int pattern = rand.nextInt(4);
            switch (pattern) {
                case 0:
                    if (r + 1 < rows - 1 && c + 1 < cols - 1) {
                        board[r][c] = CellType.WALL;
                        board[r+1][c] = CellType.WALL;
                        board[r][c+1] = CellType.WALL;
                    }
                    break;
                case 1:
                    if (r + 1 < rows - 1 && c + 2 < cols - 1) {
                        board[r][c] = CellType.WALL;
                        board[r][c+1] = CellType.WALL;
                        board[r][c+2] = CellType.WALL;
                        board[r+1][c+1] = CellType.WALL;
                    }
                    break;
                case 2:
                    if (r + 1 < rows - 1 && c + 1 < cols - 1) {
                        board[r][c] = CellType.WALL;
                        board[r+1][c] = CellType.WALL;
                        board[r][c+1] = CellType.WALL;
                        board[r+1][c+1] = CellType.WALL;
                    }
                    break;
                case 3:
                    int length = 2 + rand.nextInt(3);
                    boolean horizontal = rand.nextBoolean();
                    if (horizontal && c + length < cols - 1) {
                        for (int j = 0; j < length; j++) {
                            board[r][c+j] = CellType.WALL;
                        }
                    } else if (!horizontal && r + length < rows - 1) {
                        for (int j = 0; j < length; j++) {
                            board[r+j][c] = CellType.WALL;
                        }
                    }
                    break;
            }
        }

        List<int[]> openSpots = new ArrayList<>();
        for (int r = 1; r < rows - 1; r++) {
            for (int c = 1; c < cols - 1; c++) {
                if (board[r][c] == CellType.DOT) {
                    openSpots.add(new int[]{r, c});
                }
            }
        }
        
        if (!openSpots.isEmpty()) {
            int[] playerPos = openSpots.get(rand.nextInt(openSpots.size()));
            board[playerPos[0]][playerPos[1]] = CellType.PLAYER;
            openSpots.remove(playerPos);
        }

        int numEnemies = Math.min(4, openSpots.size());
        for (int i = 0; i < numEnemies; i++) {
            if (!openSpots.isEmpty()) {
                int[] enemyPos = openSpots.get(rand.nextInt(openSpots.size()));
                board[enemyPos[0]][enemyPos[1]] = CellType.ENEMY;
                openSpots.remove(enemyPos);
                }
            }

        ensureConnectivity();
    }

    public int getRowCount() {
        return rows;
    }

    public int getColumnCount() {
        return cols;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        return board[rowIndex][columnIndex];
    }

    public CellType getCell(int row, int col) {
        return board[row][col];
    }

    public void setCell(int row, int col, CellType type) {
        if (type == CellType.UPGRADE) {
            if (!upgradeIconsLoaded) {
                System.err.println("Warning: Attempted to set upgrade cell but icons are not loaded");
                board[row][col] = CellType.DOT;
                fireTableCellUpdated(row, col);
                return;
            }
        }
        board[row][col] = type;
        fireTableCellUpdated(row, col);
    }

    private void generateMazePrim() {

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                board[r][c] = CellType.WALL;
            }
        }

        List<int[]> frontier = new ArrayList<>();
        Set<String> visited = new HashSet<>();

        Random rand = new Random();
        int startRow = 1 + rand.nextInt((rows - 2) / 2) * 2;
        int startCol = 1 + rand.nextInt((cols - 2) / 2) * 2;

        visited.add(startRow + "," + startCol);
        board[startRow][startCol] = CellType.DOT;
        addToFrontier(startRow, startCol, frontier, visited);

        while (!frontier.isEmpty()) {

            int randomIndex = rand.nextInt(frontier.size());
            int[] current = frontier.remove(randomIndex);
            int row = current[0];
            int col = current[1];

            List<int[]> visitedNeighbors = new ArrayList<>();
            int[][] directions = {{-2,0}, {2,0}, {0,-2}, {0,2}};
            for (int[] dir : directions) {
                int newRow = row + dir[0];
                int newCol = col + dir[1];
                if (newRow > 0 && newRow < rows-1 && newCol > 0 && newCol < cols-1) {
                    if (visited.contains(newRow + "," + newCol)) {
                        visitedNeighbors.add(new int[]{newRow, newCol});
                    }
                }
            }

            if (!visitedNeighbors.isEmpty()) {

                int[] neighbor = visitedNeighbors.get(rand.nextInt(visitedNeighbors.size()));
                int wallRow = (row + neighbor[0]) / 2;
                int wallCol = (col + neighbor[1]) / 2;

                board[row][col] = CellType.DOT;
                board[wallRow][wallCol] = CellType.DOT;

                visited.add(row + "," + col);
                addToFrontier(row, col, frontier, visited);
            }
        }

        for (int r = 0; r < rows; r++) {
            board[r][0] = CellType.WALL;
            board[r][cols - 1] = CellType.WALL;
                    }
        for (int c = 0; c < cols; c++) {
            board[0][c] = CellType.WALL;
            board[rows - 1][c] = CellType.WALL;
        }

        placePlayerAndEnemies();
    }

    private void addToFrontier(int row, int col, List<int[]> frontier, Set<String> visited) {
        int[][] directions = {{-2,0}, {2,0}, {0,-2}, {0,2}};
        for (int[] dir : directions) {
            int newRow = row + dir[0];
            int newCol = col + dir[1];
            if (newRow > 0 && newRow < rows-1 && newCol > 0 && newCol < cols-1) {
                if (!visited.contains(newRow + "," + newCol)) {
                    frontier.add(new int[]{newRow, newCol});
                }}}}

    private void ensureConnectivity() {
        int[] pathRows = {rows / 4, rows / 2, 3 * rows / 4};
        int[] pathCols = {cols / 4, cols / 2, 3 * cols / 4};

        for (int col : pathCols) {
            for (int i = 1; i < rows - 1; i++) {
                if (board[i][col] == CellType.WALL) {
                    board[i][col] = CellType.DOT;
                }}}

        for (int row : pathRows) {
            for (int j = 1; j < cols - 1; j++) {
                if (board[row][j] == CellType.WALL) {
                    board[row][j] = CellType.DOT;
                }}}

        boolean[][] visited = new boolean[rows][cols];
        for (int i = 1; i < rows - 1; i++) {
            for (int j = 1; j < cols - 1; j++) {
                if (!visited[i][j] && board[i][j] == CellType.DOT) {
                    if (isIsolated(i, j, visited)) {
                        createPathToNearestSection(i, j);
                    }}}}}

    private boolean isIsolated(int row, int col, boolean[][] visited) {
        if (row < 1 || row >= rows - 1 || col < 1 || col >= cols - 1 || visited[row][col]) {
            return false;
        }

        visited[row][col] = true;
        boolean isIsolated = true;

        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] dir : directions) {
            int newRow = row + dir[0];
            int newCol = col + dir[1];
            
            if (newRow >= 1 && newRow < rows - 1 && newCol >= 1 && newCol < cols - 1) {
                if (board[newRow][newCol] == CellType.DOT && !visited[newRow][newCol]) {
                    isIsolated = false;
                    isIsolated(newRow, newCol, visited);
                }}}

        return isIsolated;
    }

    private void createPathToNearestSection(int row, int col) {
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        int minDistance = Integer.MAX_VALUE;
        int[] bestDirection = null;

        for (int[] dir : directions) {
            int distance = 0;
            int currentRow = row;
            int currentCol = col;
            
            while (currentRow >= 1 && currentRow < rows - 1 && 
                   currentCol >= 1 && currentCol < cols - 1) {
                currentRow += dir[0];
                currentCol += dir[1];
                distance++;
                
                if (board[currentRow][currentCol] == CellType.DOT) {
                    if (distance < minDistance) {
                        minDistance = distance;
                        bestDirection = dir;
                    }
                    break;
                }}}

        if (bestDirection != null) {
            int currentRow = row;
            int currentCol = col;
            for (int i = 0; i < minDistance; i++) {
                currentRow += bestDirection[0];
                currentCol += bestDirection[1];
                if (board[currentRow][currentCol] == CellType.WALL) {
                    board[currentRow][currentCol] = CellType.DOT;
                }}}}

    private void placePlayerAndEnemies() {
        int playerRow = 1;
        int playerCol = cols / 2;
        board[playerRow][playerCol] = CellType.PLAYER;

        int[][] enemyPositions = {
            {1, 1},
            {1, cols - 2},
            {rows - 2, 1},
            {rows - 2, cols - 2}
        };

        for (int[] pos : enemyPositions) {
            if (board[pos[0]][pos[1]] != CellType.WALL) {
                board[pos[0]][pos[1]] = CellType.ENEMY;
            }}}

    public boolean isGhostFrozen(int row, int col) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            return frozenGhosts[row][col];
        }
        return false;
    }

    public void setGhostFrozen(int row, int col, boolean frozen) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            this.frozenGhosts[row][col] = frozen;
            fireTableCellUpdated(row, col);
        }}

    public int getUpgradeType(int row, int col) {
        if (!upgradeIconsLoaded || !validUpgradeTypes.contains(upgradeTypes[row][col])) {
            return -1;
        }
        return upgradeTypes[row][col];
    }

    public void setUpgradeType(int row, int col, int type) {
        if (!upgradeIconsLoaded || !validUpgradeTypes.contains(type)) {
            System.err.println("Warning: Invalid upgrade type " + type + " or icons not loaded");
            board[row][col] = CellType.DOT;
            fireTableCellUpdated(row, col);
            return;
        }
        upgradeTypes[row][col] = type;
        fireTableCellUpdated(row, col);
    }

    public boolean areUpgradeIconsLoaded() {
        return upgradeIconsLoaded;
    }

    public boolean isValidUpgradeType(int type) {
        return upgradeIconsLoaded && validUpgradeTypes.contains(type);
    }

    public Set<Integer> getValidUpgradeTypes() {
        return Collections.unmodifiableSet(validUpgradeTypes);
    }
}