import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.util.HashSet;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class GameView extends JFrame implements AutoCloseable {
    private GameController controller;
    private JTable boardTable;
    private BoardTableModel boardModel;
    private int playerRow, playerCol;
    private java.util.List<int[]> enemies = new java.util.ArrayList<>();
    private java.util.Random rand = new java.util.Random();
    private final Object gameStateLock = new Object();
    private volatile boolean gameOver = false;
    private Thread enemyThread;
    private volatile boolean running = false;
    private volatile int score = 0;
    private volatile int lives = 3;
    private long startTime;
    private JLabel scoreLabel, livesLabel, timeLabel;
    private JLabel notificationLabel;
    private UITimerThread uiTimer;
    private volatile boolean playerInvincible = false;
    private volatile int speedBoostTicks = 0;
    private volatile int freezeTicks = 0;
    private volatile boolean ghostsConfused = false;
    private UpgradeSpawnerThread upgradeThread;
    private volatile boolean upgradeThreadRunning = false;
    private javax.swing.Timer scoreTimer; 
    private JPanel livesIconsPanel; 
    private JPanel topPanel;
    private BoardTableModel.CellType[][] underGhost;
    public GameView(int rows, int cols) {
        super("Pacman Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        topPanel = new JPanel();
        topPanel.setBackground(Color.BLACK);
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));
        
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setForeground(Color.WHITE);
        livesLabel = new JLabel("Lives: 3");
        livesLabel.setForeground(Color.WHITE);
        timeLabel = new JLabel("Time: 0");
        timeLabel.setForeground(Color.WHITE);
        notificationLabel = new JLabel("");
        notificationLabel.setForeground(Color.YELLOW);
        notificationLabel.setFont(new Font("Arial", Font.BOLD, 10));
        
        topPanel.add(scoreLabel);
        topPanel.add(livesLabel);
        topPanel.add(timeLabel);
        topPanel.add(notificationLabel);
        add(topPanel, BorderLayout.NORTH);


        livesIconsPanel = new JPanel();
        livesIconsPanel.setBackground(Color.BLACK);
        livesIconsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
        updateLivesIcons();
        add(livesIconsPanel, BorderLayout.SOUTH);


        boardModel = new BoardTableModel(rows, cols);
        boardTable = new JTable(boardModel);
        boardTable.setRowHeight(24);
        boardTable.setDefaultRenderer(Object.class, new BoardCellRenderer());
        boardTable.setEnabled(false);
        boardTable.setShowGrid(false);
        boardTable.setTableHeader(null);
        boardTable.setBackground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(boardTable);
        add(scrollPane, BorderLayout.CENTER);

        setSize(cols * 28, rows * 28 + 50);
        setLocationRelativeTo(null);


        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (boardModel.getCell(r, c) == BoardTableModel.CellType.PLAYER) {
                    playerRow = r;
                    playerCol = c;
                }
            }
        }


        controller = new GameController(boardModel, playerRow, playerCol);

        enemies.clear();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (boardModel.getCell(r, c) == BoardTableModel.CellType.ENEMY) {
                    enemies.add(new int[]{r, c});
                    boardModel.setGhostFrozen(r, c, false);
                }
            }
        }

        addKeyListener(new java.awt.event.KeyAdapter() {

            public void keyPressed(java.awt.event.KeyEvent e) {
                if (gameOver) return;
                int newRow = playerRow, newCol = playerCol;
                switch (e.getKeyCode()) {
                    case java.awt.event.KeyEvent.VK_UP:    newRow--; break;
                    case java.awt.event.KeyEvent.VK_DOWN:  newRow++; break;
                    case java.awt.event.KeyEvent.VK_LEFT:  newCol--; break;
                    case java.awt.event.KeyEvent.VK_RIGHT: newCol++; break;
                }
                movePacman(newRow, newCol);

                GameView.this.requestFocusInWindow();
            }
        });
        setFocusable(true);
        requestFocusInWindow();
        addWindowListener(new java.awt.event.WindowAdapter() {

            public void windowOpened(java.awt.event.WindowEvent e) {
                GameView.this.requestFocusInWindow();
            }
        });
        startTime = System.currentTimeMillis();
        startEnemyMovement();
        startUpgradeSpawner();


        uiTimer = new UITimerThread();
        uiTimer.start();

        KeyStroke quitKey = KeyStroke.getKeyStroke('Q', java.awt.event.InputEvent.CTRL_DOWN_MASK | java.awt.event.InputEvent.SHIFT_DOWN_MASK);
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(quitKey, "quitToMenu");
        getRootPane().getActionMap().put("quitToMenu", new AbstractAction() {

            public void actionPerformed(java.awt.event.ActionEvent e) {
                dispose();
                new MainMenuView().setVisible(true);
            }
        });

        underGhost = new BoardTableModel.CellType[rows][cols];
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                underGhost[r][c] = BoardTableModel.CellType.EMPTY;
    }

    private void updateUIStats() {
        scoreLabel.setText("Score: " + score);
        livesLabel.setText("Lives: " + lives);
        updateLivesIcons();

        topPanel.revalidate();
        topPanel.repaint();
    }


    private void updateLivesIcons() {
        livesIconsPanel.removeAll();
        for (int i = 0; i < lives; i++) {
            JLabel iconLabel = new JLabel();
            ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource("resources/pacman.png"));
            iconLabel.setIcon(new ImageIcon(icon.getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH)));
            livesIconsPanel.add(iconLabel);
        }
        livesIconsPanel.revalidate();
        livesIconsPanel.repaint();
    }

    private void animateMove(int fromRow, int fromCol, int toRow, int toCol, BoardTableModel.CellType type) {
        boardModel.setCell(fromRow, fromCol, BoardTableModel.CellType.EMPTY);
        boardModel.setCell(toRow, toCol, type);
        try { Thread.sleep(60); } catch (InterruptedException ignored) {}
    }

    private void startEnemyMovement() {
        running = true;
        enemyThread = new Thread(() -> {
            System.out.println("EnemyThread: Started");
            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(300);
                    if (running) {
                        moveEnemies();
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.out.println("EnemyThread: Interrupted");
                    break;
                }
            }
            System.out.println("EnemyThread: Terminated");
        });
        enemyThread.setName("EnemyMovementThread");
        enemyThread.start();
    }

    private void moveEnemies() {
        synchronized(gameStateLock) {
            if (freezeTicks > 0) {
                freezeTicks--;
                for (int[] enemy : enemies) {
                    boardModel.setGhostFrozen(enemy[0], enemy[1], true);
                }
                if (freezeTicks == 0) {
                    for (int[] enemy : enemies) {
                        boardModel.setGhostFrozen(enemy[0], enemy[1], false);
                    }
                    ghostsConfused = false;
                }
                return;
            }
            java.util.List<int[]> newPositions = new java.util.ArrayList<>();
            java.util.Set<String> occupied = new HashSet<>();
            for (int[] pos : enemies) {
                occupied.add(pos[0] + "," + pos[1]);
            }
            for (int i = 0; i < enemies.size(); i++) {
                int[] enemy = enemies.get(i);
                int[] next;
                if (ghostsConfused) {
                    next = getRandomMove(enemy[0], enemy[1], occupied);
                } else if (i == 0) {
                    next = getDirectChaserMove(enemy[0], enemy[1], occupied);
                } else if (i == 1) {
                    next = getPredictiveChaserMove(enemy[0], enemy[1], occupied);
                } else {
                    next = getRandomMove(enemy[0], enemy[1], occupied);
                }
                occupied.remove(enemy[0] + "," + enemy[1]);
                occupied.add(next[0] + "," + next[1]);
                animateGhostMove(enemy[0], enemy[1], next[0], next[1]);
                if (next[0] == playerRow && next[1] == playerCol && !playerInvincible) {
                    boardModel.setCell(next[0], next[1], BoardTableModel.CellType.ENEMY);
                    lives--;
                    updateUIStats();
                    if (lives <= 0) {
                        gameOver();
                    } else {
                        resetPlayerPosition();
                    }
                    return;
                }
                newPositions.add(next);
            }
            for (int[] pos : newPositions) {
                boardModel.setCell(pos[0], pos[1], BoardTableModel.CellType.ENEMY);
            }
            enemies = newPositions;
            checkCollision();
        }
    }

    private int[] getDirectChaserMove(int row, int col, java.util.Set<String> occupied) {
        int currentDistance = Math.abs(row - playerRow) + Math.abs(col - playerCol);
        int[][] possibleMoves = {
            {row - 1, col},
            {row + 1, col},
            {row, col - 1},
            {row, col + 1}
        };
        

        int pacmanDirection = getPacmanDirection();
        
        int bestMoveIndex = -1;
        double bestScore = Double.NEGATIVE_INFINITY;
        java.util.List<Integer> moveIndices = new java.util.ArrayList<>(java.util.Arrays.asList(0, 1, 2, 3));
        java.util.Collections.shuffle(moveIndices, rand);
        
        for (int moveIndex : moveIndices) {
            int newRow = possibleMoves[moveIndex][0];
            int newCol = possibleMoves[moveIndex][1];
            if (canMoveToEnemy(newRow, newCol) && !occupied.contains(newRow + "," + newCol)) {

                double distanceToPacman = Math.abs(newRow - playerRow) + Math.abs(newCol - playerCol);
                

                double score = -distanceToPacman;
                

                if (moveIndex == pacmanDirection) {
                    score += 2.0;
                }
                

                if (distanceToPacman > currentDistance) {
                    score -= 1.0;
                }
                
                if (score > bestScore || bestMoveIndex == -1) {
                    bestScore = score;
                    bestMoveIndex = moveIndex;
                }
            }
        }
        
        if (bestMoveIndex != -1) {
            return possibleMoves[bestMoveIndex];
        }
        return new int[]{row, col};
    }

    private int[] getPredictiveChaserMove(int row, int col, java.util.Set<String> occupied) {

        int predictedRow = playerRow;
        int predictedCol = playerCol;
        

        int pacmanDirection = getPacmanDirection();
        

        switch (pacmanDirection) {
            case 0: predictedRow--; break;
            case 1: predictedRow++; break;
            case 2: predictedCol--; break;
            case 3: predictedCol++; break;
        }
        

        if (!canMoveTo(predictedRow, predictedCol)) {

            int[][] possibleMoves = {
                {playerRow - 1, playerCol},
                {playerRow + 1, playerCol},
                {playerRow, playerCol - 1},
                {playerRow, playerCol + 1}
            };
            
            double bestScore = Double.NEGATIVE_INFINITY;
            for (int[] move : possibleMoves) {
                if (canMoveTo(move[0], move[1])) {
                    double score = -Math.abs(move[0] - row) - Math.abs(move[1] - col);
                    if (score > bestScore) {
                        bestScore = score;
                        predictedRow = move[0];
                        predictedCol = move[1];
                    }
                }
            }
        }

        int[][] possibleMoves = {
            {row - 1, col},
            {row + 1, col},
            {row, col - 1},
            {row, col + 1}
        };
        
        int bestMoveIndex = -1;
        double bestScore = Double.NEGATIVE_INFINITY;
        java.util.List<Integer> moveIndices = new java.util.ArrayList<>(java.util.Arrays.asList(0, 1, 2, 3));
        java.util.Collections.shuffle(moveIndices, rand);
        
        for (int moveIndex : moveIndices) {
            int newRow = possibleMoves[moveIndex][0];
            int newCol = possibleMoves[moveIndex][1];
            if (canMoveToEnemy(newRow, newCol) && !occupied.contains(newRow + "," + newCol)) {

                double distanceToPredicted = Math.abs(newRow - predictedRow) + Math.abs(newCol - predictedCol);
                double distanceToCurrent = Math.abs(newRow - playerRow) + Math.abs(newCol - playerCol);
                

                double score = -distanceToPredicted * 1.5 - distanceToCurrent * 0.5;
                

                if (isCuttingOffEscape(newRow, newCol, playerRow, playerCol)) {
                    score += 3.0;
                }
                
                if (score > bestScore || bestMoveIndex == -1) {
                    bestScore = score;
                    bestMoveIndex = moveIndex;
                }
            }
        }
        
        if (bestMoveIndex != -1) {
            return possibleMoves[bestMoveIndex];
        }
        return new int[]{row, col};
    }

    private int getPacmanDirection() {

        if (canMoveTo(playerRow - 1, playerCol)) return 0;
        if (canMoveTo(playerRow + 1, playerCol)) return 1;
        if (canMoveTo(playerRow, playerCol - 1)) return 2;
        if (canMoveTo(playerRow, playerCol + 1)) return 3;
        return -1;
    }

    private boolean isCuttingOffEscape(int ghostRow, int ghostCol, int pacmanRow, int pacmanCol) {

        int escapeRoutes = 0;
        int[][] possibleMoves = {
            {pacmanRow - 1, pacmanCol},
            {pacmanRow + 1, pacmanCol},
            {pacmanRow, pacmanCol - 1},
            {pacmanRow, pacmanCol + 1}
        };
        
        for (int[] move : possibleMoves) {
            if (canMoveTo(move[0], move[1])) {
                escapeRoutes++;
            }
        }
        

        return escapeRoutes <= 2 && 
               Math.abs(ghostRow - pacmanRow) + Math.abs(ghostCol - pacmanCol) <= 2;
    }

    private int[] getRandomMove(int row, int col, java.util.Set<String> occupied) {
        java.util.List<int[]> moves = new java.util.ArrayList<>();
        int[][] dirs = {{-1,0},{1,0},{0,-1},{0,1}};
        for (int[] d : dirs) {
            int nr = row + d[0], nc = col + d[1];
            if (canMoveToEnemy(nr, nc) && !occupied.contains(nr + "," + nc)) {
                moves.add(new int[]{nr, nc});
            }
        }
        if (!moves.isEmpty()) {
            return moves.get(rand.nextInt(moves.size()));
        }
        return new int[]{row, col};
    }

    private void checkCollision() {
        synchronized(gameStateLock) {
            for (int[] enemy : enemies) {
                if (enemy[0] == playerRow && enemy[1] == playerCol && !playerInvincible) {
                    lives--;
                    updateUIStats();
                    if (lives <= 0) {
                        gameOver();
                    } else {
                        resetPlayerPosition();
                    }
                    return;
                }
            }
        }
    }


    private void resetPlayerPosition() {
        boardModel.setCell(playerRow, playerCol, BoardTableModel.CellType.EMPTY);

        for (int r = 0; r < boardModel.getRowCount(); r++) {
            for (int c = 0; c < boardModel.getColumnCount(); c++) {
                if (boardModel.getCell(r, c) == BoardTableModel.CellType.PLAYER) {
                    playerRow = r;
                    playerCol = c;
                    return;
                }
            }
        }

        playerRow = boardModel.getRowCount() / 2;
        playerCol = boardModel.getColumnCount() / 2;
        boardModel.setCell(playerRow, playerCol, BoardTableModel.CellType.PLAYER);
    }

    private boolean canMoveTo(int row, int col) {
        if (row < 0 || col < 0 || row >= boardModel.getRowCount() || col >= boardModel.getColumnCount()) return false;
        BoardTableModel.CellType cell = boardModel.getCell(row, col);

        return cell != BoardTableModel.CellType.WALL;
    }

    private boolean canMoveToEnemy(int row, int col) {
        if (row < 0 || col < 0 || row >= boardModel.getRowCount() || col >= boardModel.getColumnCount()) return false;
        BoardTableModel.CellType cell = boardModel.getCell(row, col);

        return cell != BoardTableModel.CellType.WALL;
    }

    private void gameOver() {
        gameOver = true;
        running = false;
        upgradeThreadRunning = false;
        

        if (enemyThread != null) enemyThread.interrupt();
        if (upgradeThread != null) upgradeThread.interrupt();
        if (scoreTimer != null) scoreTimer.stop();
        if (uiTimer != null) uiTimer.terminate();


        SwingUtilities.invokeLater(() -> {
            String name = JOptionPane.showInputDialog(this, "Game Over! Please enter your name:");
            if (name != null && !name.trim().isEmpty()) {
                HighScores.saveScore(name.trim(), score);
                JOptionPane.showMessageDialog(this, "Score saved!");
            }
            dispose();
            new MainMenuView().setVisible(true);
        });
    }

    public BoardTableModel getBoardModel() {
        return boardModel;
    }

    private void showNotification(String message) {
        SwingUtilities.invokeLater(() -> {
            notificationLabel.setText(message);
            notificationLabel.setVisible(true);
            
            javax.swing.Timer timer = new javax.swing.Timer(2000, e -> {
                notificationLabel.setText("");
                notificationLabel.setVisible(false);
                ((javax.swing.Timer)e.getSource()).stop();
            });
            timer.setRepeats(false);
            timer.start();
        });
    }

    private void applyPowerUpEffect(int upgradeType) {
        synchronized(gameStateLock) {
            switch (upgradeType) {
                case BoardTableModel.UPGRADE_LIFE:
                    lives++;
                    showNotification("+1 Life!");
                    break;
                case BoardTableModel.UPGRADE_SCORE:
                    score += 100;
                    showNotification("+100 Score!");
                    break;
                case BoardTableModel.UPGRADE_INVINCIBILITY:
                    playerInvincible = true;
                    ghostsConfused = true;
                    showNotification("Invincible! Ghosts are confused!");
                    new Thread(() -> {
                        try { 
                            Thread.sleep(3000); 
                        } catch (InterruptedException ignored) {}
                        synchronized(gameStateLock) {
                            playerInvincible = false;
                            ghostsConfused = false;
                        }
                    }).start();
                    break;
                case BoardTableModel.UPGRADE_FREEZE:
                    freezeTicks = 10;
                    showNotification("Enemies frozen for 10 moves!");
                    break;
                case BoardTableModel.UPGRADE_TELEPORT:
                     int r, c;
                     do {
                         r = rand.nextInt(boardModel.getRowCount());
                         c = rand.nextInt(boardModel.getColumnCount());
                     } while (boardModel.getCell(r, c) != BoardTableModel.CellType.DOT);

                     boardModel.setCell(playerRow, playerCol, BoardTableModel.CellType.EMPTY);
                     animateMove(playerRow, playerCol, r, c, BoardTableModel.CellType.PLAYER);
                     playerRow = r;
                     playerCol = c;
                     showNotification("Teleport!");
                    break;

                default:
                    System.err.println("Unknown upgrade type: " + upgradeType);
                    break;
            }
            updateUIStats();
        }
    }

    private void startUpgradeSpawner() {
        System.out.println("Starting upgrade spawner thread...");
        upgradeThread = new UpgradeSpawnerThread(boardModel);
        upgradeThread.setName("UpgradeSpawnerThread");
        upgradeThread.start();
        System.out.println("Upgrade spawner thread started successfully");
    }

    public void close() {
        dispose();
        cleanupResources();
    }

    private void cleanupResources() {
        running = false;
        upgradeThreadRunning = false;


        if (enemyThread != null) {
            System.out.println("Terminating enemy thread...");
            enemyThread.interrupt();
            try {
                enemyThread.join(1000);
                if (enemyThread.isAlive()) {
                    System.err.println("Warning: Enemy thread did not terminate gracefully after 1 second");
                } else {
                    System.out.println("Enemy thread terminated successfully");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error while terminating enemy thread: " + e.getMessage());
            }
        }

        if (upgradeThread != null) {
            System.out.println("Terminating upgrade thread...");
            upgradeThread.terminate();
            try {
                upgradeThread.join(1000);
                if (upgradeThread.isAlive()) {
                    System.err.println("Warning: Upgrade thread did not terminate gracefully after 1 second");
                } else {
                    System.out.println("Upgrade thread terminated successfully");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error while terminating upgrade thread: " + e.getMessage());
            }
        }


        if (uiTimer != null) {
            System.out.println("Terminating UI timer thread...");
            uiTimer.terminate();
            try {
                uiTimer.join(1000);
                if (uiTimer.isAlive()) {
                    System.err.println("Warning: UI timer thread did not terminate gracefully after 1 second");
                } else {
                    System.out.println("UI timer thread terminated successfully");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error while terminating UI timer thread: " + e.getMessage());
            }
        }


        if (scoreTimer != null) {
            System.out.println("Stopping score timer...");
            scoreTimer.stop();
            System.out.println("Score timer stopped successfully");
        }

        if (enemies != null) {
            System.out.println("Cleaning up enemies collection...");
            enemies.clear();
            System.out.println("Enemies collection cleaned up successfully");
        }
        if (underGhost != null) {
            System.out.println("Cleaning up underGhost array...");
            for (int i = 0; i < underGhost.length; i++) {
                for (int j = 0; j < underGhost[i].length; j++) {
                    underGhost[i][j] = null;
                }
            }
            System.out.println("UnderGhost array cleaned up successfully");
        }
    }

    public void dispose() {
        cleanupResources();
        super.dispose();
    }

    private boolean checkForWin() {
        for (int r = 0; r < boardModel.getRowCount(); r++) {
            for (int c = 0; c < boardModel.getColumnCount(); c++) {
                if (boardModel.getCell(r, c) == BoardTableModel.CellType.DOT) {
                    return false;
                }
            }
        }
        return true;
    }

    private void showVictoryMessage() {
        gameOver = true;
        running = false;
        upgradeThreadRunning = false;
        

        if (enemyThread != null) enemyThread.interrupt();
        if (upgradeThread != null) upgradeThread.interrupt();
        if (scoreTimer != null) scoreTimer.stop();
        if (uiTimer != null) uiTimer.terminate();


        SwingUtilities.invokeLater(() -> {
            String name = JOptionPane.showInputDialog(this, "You won! Please enter your name:");
            if (name != null && !name.trim().isEmpty()) {
                HighScores.saveScore(name.trim(), score);
                JOptionPane.showMessageDialog(this, "Score saved!");
            }
            dispose();
            new MainMenuView().setVisible(true);
        });
    }

    private void movePacman(int newRow, int newCol) {
        synchronized(gameStateLock) {
            if (canMoveTo(newRow, newCol)) {
                BoardTableModel.CellType cellType = boardModel.getCell(newRow, newCol);
                BoardTableModel.CellType currentCell = boardModel.getCell(playerRow, playerCol);
                
                animateMove(playerRow, playerCol, newRow, newCol, BoardTableModel.CellType.PLAYER);
                playerRow = newRow;
                playerCol = newCol;
                
                if (cellType == BoardTableModel.CellType.DOT) {
                    score += 10;
                    boardModel.setCell(playerRow, playerCol, BoardTableModel.CellType.PLAYER);
                    
                    if (checkForWin()) {
                        showVictoryMessage();
                        return;
                    }
                } else if (cellType == BoardTableModel.CellType.UPGRADE) {
                    boardModel.setCell(playerRow, playerCol, BoardTableModel.CellType.PLAYER);
                    int upgradeType = boardModel.getUpgradeType(playerRow, playerCol);
                    applyPowerUpEffect(upgradeType);
                }
                
                updateUIStats();
                checkCollision();
            }
        }
    }


    private class UITimerThread extends Thread {
        private volatile boolean running = true;

        public void terminate() {
            System.out.println("UITimerThread: Received termination signal");
            running = false;
            interrupt();
        }


        public void run() {
            System.out.println("UITimerThread: Started");
            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(1000);
                    if (running) {
                        SwingUtilities.invokeLater(() -> {
                            if (running) {
                                long currentTime = System.currentTimeMillis();
                                long elapsedTime = (currentTime - startTime) / 1000;
                                timeLabel.setText("Time: " + elapsedTime);
                            }
                        });
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.out.println("UITimerThread: Interrupted");
                    break;
                }
            }
            System.out.println("UITimerThread: Terminated");
        }
    }


    private void animateGhostMove(int fromRow, int fromCol, int toRow, int toCol) {

        boardModel.setCell(fromRow, fromCol, underGhost[fromRow][fromCol]);

        underGhost[toRow][toCol] = boardModel.getCell(toRow, toCol) == BoardTableModel.CellType.ENEMY ? BoardTableModel.CellType.EMPTY : boardModel.getCell(toRow, toCol);

        boardModel.setCell(toRow, toCol, BoardTableModel.CellType.ENEMY);
    }

    private void resetGame() {
        System.out.println("Resetting game state...");
        

        if (boardModel != null) {

            List<int[]> ghostPositions = new ArrayList<>();
            for (int r = 0; r < boardModel.getRowCount(); r++) {
                for (int c = 0; c < boardModel.getColumnCount(); c++) {
                    if (boardModel.getCell(r, c) == BoardTableModel.CellType.ENEMY) {
                        ghostPositions.add(new int[]{r, c});
                    }
                }
            }

            boardModel.setCell(1, 1, BoardTableModel.CellType.PLAYER);
            playerRow = 1;
            playerCol = 1;

            for (int[] pos : ghostPositions) {
                boardModel.setCell(pos[0], pos[1], BoardTableModel.CellType.ENEMY);
            }
        }

        score = 0;
        lives = 3;
        scoreLabel.setText("Score: 0");
        livesLabel.setText("Lives: 3");
        startTime = System.currentTimeMillis();
        timeLabel.setText("Time: 0");

        if (scoreTimer != null) {
            scoreTimer.restart();
        }
        if (uiTimer != null) {
            uiTimer.terminate();
            uiTimer = new UITimerThread();
            uiTimer.start();
        }

        System.out.println("Game reset completed. Ghost positions preserved.");
    }
}