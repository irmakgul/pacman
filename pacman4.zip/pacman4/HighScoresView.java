import javax.swing.*;
import java.awt.*;
import java.util.List;

public class HighScoresView extends JFrame {
    private Image backgroundImage;

    public HighScoresView() {
        super("Pacman - High Scores");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 500);
        setLocationRelativeTo(null);


        backgroundImage = new ImageIcon(getClass().getClassLoader().getResource("resources/scorebackground.png")).getImage();


        JPanel mainPanel = new JPanel() {
       
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setLayout(new BorderLayout());
        setContentPane(mainPanel);


        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        JLabel title = new JLabel("High Scores", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 32));
        title.setForeground(Color.YELLOW);
        titlePanel.add(title);
        mainPanel.add(titlePanel, BorderLayout.NORTH);


        JPanel scoresPanel = new JPanel(new BorderLayout());
        scoresPanel.setOpaque(false);
        
        List<HighScores.ScoreEntry> scores = HighScores.getScores();
        DefaultListModel<String> listModel = new DefaultListModel<>();
        
        if (scores != null) {
            for (int i = 0; i < scores.size(); i++) {
                listModel.addElement((i + 1) + ". " + scores.get(i).name + " - " + scores.get(i).score);
            }
        } else {
            listModel.addElement("Could not load high scores.");
        }

        JList<String> scoreList = new JList<>(listModel);
        scoreList.setFont(new Font("Arial", Font.BOLD, 20));
        scoreList.setForeground(Color.WHITE);
        scoreList.setBackground(new Color(0, 0, 0, 150));
        scoreList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scoreList.setLayoutOrientation(JList.VERTICAL);
        scoreList.setVisibleRowCount(-1);

        JScrollPane listScrollPane = new JScrollPane(scoreList);
        listScrollPane.setOpaque(false);
        listScrollPane.getViewport().setOpaque(false);
        listScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scoresPanel.add(listScrollPane, BorderLayout.CENTER);
        mainPanel.add(scoresPanel, BorderLayout.CENTER);


        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        JButton backButton = createStyledButton("Back");
        backButton.addActionListener(e -> dispose());
        buttonPanel.add(backButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);


        KeyStroke quitKey = KeyStroke.getKeyStroke('Q', java.awt.event.InputEvent.CTRL_DOWN_MASK | java.awt.event.InputEvent.SHIFT_DOWN_MASK);
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(quitKey, "quitToMenu");
        getRootPane().getActionMap().put("quitToMenu", new AbstractAction() {
          
            public void actionPerformed(java.awt.event.ActionEvent e) {
                dispose();
                new MainMenuView().setVisible(true);
            }
        });
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 0, 170));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(120, 40));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 0, 200));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 0, 170));
            }
        });
        
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new HighScoresView().setVisible(true);
        });
    }
}