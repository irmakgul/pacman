import java.io.*;
import java.util.*;
import javax.swing.*;

public class HighScores implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String FILE = "highscores.dat";
    private static final int MAX_SCORES = 10;
    private static List<ScoreEntry> scores = load();

    public static void saveScore(String name, int score) {
        scores.add(new ScoreEntry(name, score));
        scores.sort((a, b) -> Integer.compare(b.score, a.score));
        if (scores.size() > MAX_SCORES) {
            scores = scores.subList(0, MAX_SCORES);
        }
        save();
    }

    public static List<ScoreEntry> getScores() {
        return new ArrayList<>(scores);
    }

    private static void save() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE))) {
            out.writeObject(scores);
        } catch (IOException e) {

        }
    }

    @SuppressWarnings("unchecked")
    private static List<ScoreEntry> load() {
        File file = new File(FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (List<ScoreEntry>) in.readObject();
        } catch (Exception e) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(
                    null,
                    "Failed to load high scores:\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
            });
            return new ArrayList<>();
        }
    }

    public static class ScoreEntry implements Serializable {
        private static final long serialVersionUID = 1L;
        public final String name;
        public final int score;
        public final long timestamp;

        public ScoreEntry(String name, int score) {
            this.name = name;
            this.score = score;
            this.timestamp = System.currentTimeMillis();
        }

        public String toString() {
            return String.format("%-15s %6d", name, score);
        }

        public String getFormattedDate() {
            return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date(timestamp));
        }
    }
}