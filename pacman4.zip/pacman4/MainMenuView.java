import javax.swing.*;
import java.awt.*;

public class MainMenuView extends JFrame {
    private Image backgroundImage;

    public MainMenuView() {
        super("Pacman - Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);


        backgroundImage = new ImageIcon(getClass().getClassLoader().getResource("resources/background.png")).getImage();


        JPanel mainPanel = new JPanel() {

            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setLayout(new GridBagLayout());
        setContentPane(mainPanel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("PACMAN", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 33));
        title.setForeground(Color.YELLOW);
        gbc.gridy = 0;
        mainPanel.add(title, gbc);

        JButton startButton = new JButton("New Game");
        gbc.gridy = 1;
        mainPanel.add(startButton, gbc);

        JButton highScoresButton = new JButton("High Scores");
        gbc.gridy = 2;
        mainPanel.add(highScoresButton, gbc);

        JButton exitButton = new JButton("Exit");
        gbc.gridy = 3;
        mainPanel.add(exitButton, gbc);


        for (Component comp : mainPanel.getComponents()) {
            if (comp instanceof JButton) {
                JButton button = (JButton) comp;
                button.setOpaque(true);
                button.setBackground(new Color(0, 0, 170));
                button.setForeground(Color.BLUE);
                button.setFocusPainted(false);
            }
        }

        startButton.addActionListener(e -> {

            JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
            JTextField rowField = new JTextField("20");
            JTextField colField = new JTextField("20");
            
            panel.add(new JLabel("Number of rows (10-100):"));
            panel.add(rowField);
            panel.add(new JLabel("Number of columns (10-100):"));
            panel.add(colField);

            int result = JOptionPane.showConfirmDialog(this, panel, 
                "Enter Board Size", JOptionPane.OK_CANCEL_OPTION);
            
            if (result == JOptionPane.OK_OPTION) {
                int rows = 20;
                int cols = 20;
                boolean validInput = true;
                
                try {
                    rows = Integer.parseInt(rowField.getText().trim());
                    cols = Integer.parseInt(colField.getText().trim());
                    
                    if (rows < 10 || rows > 100 || cols < 10 || cols > 100) {
                        validInput = false;
                    }
                } catch (Exception ex) {
                    validInput = false;
                }
                
                if (!validInput) {
                    JOptionPane.showMessageDialog(this, 
                        "Invalid input! Please enter numbers between 10 and 100.", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                GameView game = new GameView(rows, cols);
                game.setVisible(true);
                this.dispose();
            }
        });
        highScoresButton.addActionListener(e -> new HighScoresView().setVisible(true));
        exitButton.addActionListener(e -> System.exit(0));
    }
}