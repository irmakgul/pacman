import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class BoardCellRenderer extends JPanel implements TableCellRenderer {
    private static final Map<BoardTableModel.CellType, Image> icons = new HashMap<>();
    private static final Image redGhostIcon = loadIcon("resources/ghost_red.png");
    private static final Image whiteGhostIcon = loadIcon("resources/ghost_white.png");
    private static final Map<Integer, Image> upgradeIcons = new HashMap<>();
    private static boolean iconsLoaded = false;
    private static final Color DEFAULT_UPGRADE_COLOR = new Color(255, 215, 0);

    static {
        try {

            icons.put(BoardTableModel.CellType.PLAYER, loadIcon("resources/pacman.png"));
            icons.put(BoardTableModel.CellType.DOT, loadIcon("resources/dot.png"));


            upgradeIcons.put(BoardTableModel.UPGRADE_LIFE, loadIcon("resources/life.png"));
            upgradeIcons.put(BoardTableModel.UPGRADE_SCORE, loadIcon("resources/score.png"));
            upgradeIcons.put(BoardTableModel.UPGRADE_INVINCIBILITY, loadIcon("resources/invincibility.png"));
            upgradeIcons.put(BoardTableModel.UPGRADE_FREEZE, loadIcon("resources/freeze.png"));
            upgradeIcons.put(BoardTableModel.UPGRADE_TELEPORT, loadIcon("resources/teleport.png"));


            iconsLoaded = icons.values().stream().allMatch(img -> img != null) &&
                         upgradeIcons.values().stream().allMatch(img -> img != null);

            if (!iconsLoaded) {
                System.err.println("Warning: Some icons failed to load!");

                if (icons.get(BoardTableModel.CellType.PLAYER) == null) {
                    System.err.println("Warning: Pacman icon not loaded, using fallback");
                }
                if (icons.get(BoardTableModel.CellType.DOT) == null) {
                    System.err.println("Warning: Dot icon not loaded, using fallback");
                }
                if (redGhostIcon == null) {
                    System.err.println("Warning: Red ghost icon not loaded, using fallback");
                }
                if (whiteGhostIcon == null) {
                    System.err.println("Warning: White ghost icon not loaded, using fallback");
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading icons: " + e.getMessage());
            iconsLoaded = false;
        }
    }

    private static Image loadIcon(String path) {
        try {
            java.net.URL imgURL = BoardCellRenderer.class.getClassLoader().getResource(path);
            System.out.println("Loading: " + path + " -> " + (imgURL != null ? "FOUND" : "NOT FOUND"));
            if (imgURL != null) {
                ImageIcon icon = new ImageIcon(imgURL);
                return icon.getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH);
            }
        } catch (Exception e) {
            System.err.println("Error loading icon " + path + ": " + e.getMessage());
        }
        return null;
    }

    private BoardTableModel.CellType cellType;
    private BoardTableModel boardModel;
    private int row, col;

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        this.cellType = (BoardTableModel.CellType) value;
        this.row = row;
        this.col = column;
        this.boardModel = (BoardTableModel) table.getModel();
        setOpaque(false);
        return this;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        int w = getWidth();
        int h = getHeight();

        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, w, h);

        if (cellType == BoardTableModel.CellType.WALL) {
            g2.setColor(Color.BLUE);
            g2.setStroke(new BasicStroke(4));

            if (row == 0 || (boardModel != null && boardModel.getCell(row - 1, col) != BoardTableModel.CellType.WALL))
                g2.drawLine(0, 0, w, 0);

            if (row == (boardModel != null ? boardModel.getRowCount() - 1 : this.row) || (boardModel != null && boardModel.getCell(row + 1, col) != BoardTableModel.CellType.WALL))
                g2.drawLine(0, h - 1, w, h - 1);

            if (col == 0 || (boardModel != null && boardModel.getCell(row, col - 1) != BoardTableModel.CellType.WALL))
                g2.drawLine(0, 0, 0, h);
            
            if (col == (boardModel != null ? boardModel.getColumnCount() - 1 : this.col) || (boardModel != null && boardModel.getCell(row, col + 1) != BoardTableModel.CellType.WALL))
                g2.drawLine(w - 1, 0, w - 1, h);
        }

        if (cellType == BoardTableModel.CellType.DOT) {
            Image img = icons.get(BoardTableModel.CellType.DOT);
            if (img != null) {
                g2.drawImage(img, 0, 0, w, h, null);
            } else {
                g2.setColor(Color.YELLOW);
                int dotSize = Math.min(w, h) / 5;
                g2.fillOval((w - dotSize) / 2, (h - dotSize) / 2, dotSize, dotSize);
            }
        }

        if (cellType == BoardTableModel.CellType.UPGRADE && boardModel != null) {
            int upgradeType = boardModel.getUpgradeType(row, col);
            Image upgradeImg = upgradeIcons.get(upgradeType);
            if (upgradeImg != null) {
                g2.drawImage(upgradeImg, 0, 0, w, h, null);
            } else {

                g2.setColor(DEFAULT_UPGRADE_COLOR);
                g2.fillOval(w/4, h/4, w/2, h/2);
                g2.setColor(Color.BLACK);
                g2.drawOval(w/4, h/4, w/2, h/2);
            }
        }

        if (cellType == BoardTableModel.CellType.PLAYER) {
            Image img = icons.get(BoardTableModel.CellType.PLAYER);
            if (img != null) {
                g2.drawImage(img, 0, 0, w, h, null);
            } else {

                g2.setColor(Color.YELLOW);
                g2.fillArc(2, 2, w - 4, h - 4, 30, 300);
            }
        }

        if (cellType == BoardTableModel.CellType.ENEMY) {
            if (boardModel != null && boardModel.isGhostFrozen(row, col)) {
                if (whiteGhostIcon != null) {
                    g2.drawImage(whiteGhostIcon, 0, 0, w, h, null);
                } else {

                    g2.setColor(Color.WHITE);
                    g2.fillOval(2, 2, w - 4, h - 4);
                }
            } else {
                if (redGhostIcon != null) {
                    g2.drawImage(redGhostIcon, 0, 0, w, h, null);
                } else {

                    g2.setColor(Color.RED);
                    g2.fillOval(2, 2, w - 4, h - 4);
                }
            }
        }

        g2.dispose();
    }

    public Dimension getPreferredSize() {
        return new Dimension(24, 24);
    }
}