public class Main {
    public static void main(String[] args) {
        try {

            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("Warning: Could not set system look and feel: " + e.getMessage());
            try {

                javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ex) {
                System.err.println("Error: Could not set cross-platform look and feel: " + ex.getMessage());

            }
        }

        javax.swing.SwingUtilities.invokeLater(() -> {
            try {
                MainMenuView menu = new MainMenuView();
                menu.setVisible(true);
            } catch (Exception e) {
                System.err.println("Error: Failed to start game: " + e.getMessage());
                e.printStackTrace();
                System.exit(1);
            }
        });
    }
}