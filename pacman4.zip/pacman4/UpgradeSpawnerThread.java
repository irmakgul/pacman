public class UpgradeSpawnerThread extends Thread {
    private final BoardTableModel boardModel;
    private volatile boolean running = true;
    private final java.util.Random rand = new java.util.Random();
    private volatile int upgradeCount = 0;
    private final Object spawnLock = new Object();
    private static final long SPAWN_INTERVAL = 5000;

    public UpgradeSpawnerThread(BoardTableModel boardModel) {
        this.boardModel = boardModel;
        setDaemon(true);
    }

    public void terminate() {
        running = false;
        interrupt();
        try {
            join(1000);
            if (isAlive()) {
                System.err.println("Warning: UpgradeSpawnerThread did not terminate gracefully");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void spawnUpgradeAtGhostPosition(int ghostRow, int ghostCol) {
        if (!running) return;
        
        synchronized(spawnLock) {
            if (!running) return;

            if (!boardModel.areUpgradeIconsLoaded()) {
                System.out.println("UpgradeSpawner: Upgrade icons not loaded, skipping spawn");
                return;
            }

            System.out.println("UpgradeSpawner: Attempting to spawn upgrade at ghost position...");

            int[] possiblePositions = {
                ghostRow - 1, ghostCol,
                ghostRow + 1, ghostCol,
                ghostRow, ghostCol - 1,
                ghostRow, ghostCol + 1
            };

            java.util.List<int[]> validPositions = new java.util.ArrayList<>();
            
            for (int i = 0; i < possiblePositions.length; i += 2) {
                int row = possiblePositions[i];
                int col = possiblePositions[i + 1];
                
                if (row >= 0 && row < boardModel.getRowCount() && 
                    col >= 0 && col < boardModel.getColumnCount() && 
                    boardModel.getCell(row, col) == BoardTableModel.CellType.DOT) {
                    validPositions.add(new int[]{row, col});
                }
            }

            if (!validPositions.isEmpty()) {
                int[] selectedCell = validPositions.get(rand.nextInt(validPositions.size()));
                int row = selectedCell[0];
                int col = selectedCell[1];

                int upgradeType = rand.nextInt(5);
                
                if (boardModel.isValidUpgradeType(upgradeType)) {
                    boardModel.setCell(row, col, BoardTableModel.CellType.UPGRADE);
                    boardModel.setUpgradeType(row, col, upgradeType);
                    upgradeCount++;
                    System.out.println("UpgradeSpawner: Spawned upgrade #" + upgradeCount + " (Type: " + upgradeType + ") at position [" + row + "," + col + "]");
                } else {
                    System.out.println("UpgradeSpawner: Invalid upgrade type " + upgradeType + ", skipping spawn");
                }
            } else {
                System.out.println("UpgradeSpawner: No valid positions available behind ghost for upgrade spawn");
            }
        }
    }

    public void run() {
        long nextSpawnTime = System.currentTimeMillis() + SPAWN_INTERVAL;
        
        while (running && !Thread.currentThread().isInterrupted()) {
            try {
                long currentTime = System.currentTimeMillis();
                long sleepTime = nextSpawnTime - currentTime;
                
                if (sleepTime > 0) {
                    Thread.sleep(sleepTime);
                }
                
                if (running && !Thread.currentThread().isInterrupted()) {
                    if (rand.nextDouble() < 0.99) {
                        for (int r = 0; r < boardModel.getRowCount() && running; r++) {
                            for (int c = 0; c < boardModel.getColumnCount() && running; c++) {
                                if (boardModel.getCell(r, c) == BoardTableModel.CellType.ENEMY) {
                                    spawnUpgradeAtGhostPosition(r, c);
                                }
                            }
                        }
                    }
                    nextSpawnTime = System.currentTimeMillis() + SPAWN_INTERVAL;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
}