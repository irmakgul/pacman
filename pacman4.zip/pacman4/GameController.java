import java.awt.event.KeyEvent;

public class GameController implements AutoCloseable {
    private final BoardTableModel model;
    private volatile int playerRow;
    private volatile int playerCol;
    private volatile boolean isInvincible;
    private final Object controllerLock = new Object();

    public GameController(BoardTableModel model, int startRow, int startCol) {
        this.model = model;
        this.playerRow = startRow;
        this.playerCol = startCol;
        this.isInvincible = false;
    }

    public void setInvincible(boolean invincible) {
        synchronized(controllerLock) {
            this.isInvincible = invincible;
        }
    }

    public void onKeyPressed(int keyCode) {
        synchronized(controllerLock) {
            int newRow = playerRow;
            int newCol = playerCol;

            switch (keyCode) {
                case KeyEvent.VK_UP: newRow--; break;
                case KeyEvent.VK_DOWN: newRow++; break;
                case KeyEvent.VK_LEFT: newCol--; break;
                case KeyEvent.VK_RIGHT: newCol++; break;
            }

            if (model.isWalkable(newRow, newCol)) {
                BoardTableModel.CellType currentCell = model.getCell(playerRow, playerCol);
                BoardTableModel.CellType nextCell = model.getCell(newRow, newCol);
                
                if (isInvincible && nextCell == BoardTableModel.CellType.ENEMY) {
                    model.setCell(playerRow, playerCol, BoardTableModel.CellType.EMPTY);
                    playerRow = newRow;
                    playerCol = newCol;
                    model.setCell(playerRow, playerCol, BoardTableModel.CellType.PLAYER);
                } else {
                    model.setCell(playerRow, playerCol, BoardTableModel.CellType.EMPTY);
                    playerRow = newRow;
                    playerCol = newCol;
                    model.setCell(playerRow, playerCol, BoardTableModel.CellType.PLAYER);
                }
            }
        }
    }

    public int getPlayerRow() {
        synchronized(controllerLock) {
            return playerRow;
        }
    }

    public int getPlayerCol() {
        synchronized(controllerLock) {
            return playerCol;
        }
    }


    public void close() {
        synchronized(controllerLock) {

            isInvincible = false;

        }
    }
}
